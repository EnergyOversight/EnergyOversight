# Langager Energi

Mobilvenlig prototype. Upload `index.html` til et offentligt GitHub-repository og aktiver GitHub Pages under Settings → Pages → Deploy from a branch → main → /(root).

**Vigtigt:** Ingen API-nøgler, passwords eller alarmoplysninger må lægges i dette repository. Verisure-tal er historiske eksempler, ikke live-data.
