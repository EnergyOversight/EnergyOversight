# EnergyOversight v3

GitHub Pages reads `prices.json` generated hourly by GitHub Actions. Requires repository Actions enabled and permission for Actions to write repository contents (Settings → Actions → General → Workflow permissions → Read and write permissions). Run the workflow manually once in Actions → Update DK2 spot prices → Run workflow.

Upload `index.html`, `fetch_prices.py`, and `.github/workflows/prices.yml` with their exact paths. GitHub mobile upload can be difficult for nested paths; GitHub web Create new file accepts `.github/workflows/prices.yml` as a filename.

Prices are spot prices only, not retail prices. Do not store private API credentials in public files.
